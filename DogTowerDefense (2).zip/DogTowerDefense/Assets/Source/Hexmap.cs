﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hexmap : MonoBehaviour
{
    // Unity Functions
    void Start()
    {
        GenerateTilemap();
    }

    // Member Variables
    public GameObject hexPrefab = null;
    //public Material[] hexMats = null;
    public Material terrainMat = null;
    public Material groundMat = null;

    private int hexRows = 60;
    private int hexCols = 30;
    private Hex[ , ] hexes = null;
    private Dictionary<Hex, GameObject> dictHexToGameObj;

    // Public Methods
    public virtual void GenerateTilemap()
    {
        hexes = new Hex[hexCols, hexRows];
        dictHexToGameObj = new Dictionary<Hex, GameObject>();

        for (int col = 0; col < hexRows; col++)
        {
            for (int row = 0; row < hexCols; row++)
            {
                // Create new Hex w/ radius of 1f
                Hex hex = new Hex(col, row, 1f);
                hex.drawHexSection = false;

                // Assign created hex into spot in hexes array
                hexes[row, col] = hex;

                // Instantiate hex tiles (parent transform to this Tilemap)
                GameObject hexObj = (GameObject)Instantiate(hexPrefab, hex.GetWorldPosition(), Quaternion.identity, this.transform);

                dictHexToGameObj[hex] = hexObj; // TODO: use add call instead?

                // Show hex coordinates
                hexObj.GetComponentInChildren<TextMesh>().text = string.Format("{0}, {1}", col, row);
            }
        }

        UpdateTileVisuals();

        // Static objects can be batched together to reduce the number of draw calls
        //StaticBatchingUtility.Combine(this.gameObject);
    }

    public Hex GetHexAtCoord(int x, int y)
    {
        if (hexes == null)
        {
            Debug.Log("Hexes not instantiated.");
        }

        return hexes[x, y];
    }

    public Hex[] GetHexesWithinRadius(Hex centerHex, int radius)
    {
        List<Hex> hexesToReturn = new List<Hex>();

        for (int dx = -radius; dx < radius - 1; dx++)
        {
            for (int dy = Mathf.Max(-radius + 1, -dx - radius); dy < Mathf.Min(radius, -dx + radius - 1); dy++)
            {
                hexesToReturn.Add(hexes[centerHex.q + dx, centerHex.r + dy]);
            }
        }

        return hexesToReturn.ToArray();
    }

    public void UpdateTileVisuals()
    {
        for (int col = 0; col < hexCols; col++)
        {
            for (int row = 0; row < hexRows; row++)
            {
                Hex hex = hexes[col, row];
                GameObject hexObj = dictHexToGameObj[hex];

                // Change hex material
                MeshRenderer meshRenderer = hexObj.GetComponentInChildren<MeshRenderer>();
                if (hex.drawHexSection == true)
                {
                    meshRenderer.material = groundMat;
                }
                else
                {
                    meshRenderer.material = terrainMat;
                }
            }
        }
    }
}
