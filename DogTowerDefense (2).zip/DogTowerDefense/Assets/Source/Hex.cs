﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/*
 * Hex Base Class
 * 
 * Contains properties and positions of each hex.
 */
public class Hex
{
    // Constructor(s)
    public Hex(int q, int r, float radius)
    {
        // since:       x + y + z = 0
        // therefore:   z = -(x + y)
        this.q = q;
        this.r = r;
        s = -(q + r);
        this.radius = radius;
    }

    // Member Variables
    public readonly int q = 0; // col
    public readonly int r = 0; // row
    public readonly int s = 0;
    public readonly float radius = 0;
    public bool drawHexSection = false;

    private static readonly float WIDTH_MULTIPLIER = Mathf.Sqrt(3) / 2;

    // Public Methods
    public Vector3 GetWorldPosition()
    {
        return new Vector3(GetHexHorizontalOffset() * (q + r / 2f), 0, GetHexVerticalOffset() * r);
    }

    public float GetHexHeight()
    {
        return radius * 2;
    }

    public float GetHexWidth()
    {
        // width = WIDTH_MULTIPLIER * height
        // this is because a pointed top hex isn't exactly 2 unity units in width
        return WIDTH_MULTIPLIER * GetHexHeight();
    }

    public float GetHexVerticalOffset()
    {
        return GetHexHeight() * 0.75f;
    }

    public float GetHexHorizontalOffset()
    {
        return GetHexWidth();
    }

    public Vector3 GetPositionFromCamera(Vector3 cameraPosition, float hexRows, float hexCols)
    {
        float mapHeight = hexRows * GetHexVerticalOffset();
        float mapWidth = hexCols * GetHexHorizontalOffset();

        return new Vector3();
    }
}
