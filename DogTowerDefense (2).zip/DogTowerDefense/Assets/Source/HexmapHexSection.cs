﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HexmapHexSection : Hexmap
{
    public override void GenerateTilemap()
    {
        base.GenerateTilemap();

        SelectSection(21, 15, 3);

        UpdateTileVisuals();
    }

    private void SelectSection(int q, int r, int radius)
    {
        Hex centerHex = GetHexAtCoord(q, r);
        Hex[] areaOfHexes = GetHexesWithinRadius(centerHex, radius);
        centerHex.drawHexSection = true;
        //foreach (Hex hex in areaOfHexes)
        //{
        //    hex.drawHexSection = true;
        //}
    }
}
