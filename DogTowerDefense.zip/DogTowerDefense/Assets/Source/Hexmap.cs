﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hexmap : MonoBehaviour
{
    // Unity Functions
    void Start()
    {
        GenerateTilemap();
    }

    // Member Variables
    public GameObject hexPrefab = null;
    public Material[] hexMats = null;

    private int hexRows = 40;
    private int hexCols = 20;
    private Hex[ , ] hexes = null;

    // Public Methods
    public void GenerateTilemap()
    {
        for (int col = 0; col < hexRows; col++)
        {
            for (int row = 0; row < hexCols; row++)
            {
                // Instantiate hex tiles (parent transform to this Tilemap)
                Hex hex = new Hex(col, row, 1f);

                GameObject hexObj = (GameObject)Instantiate(hexPrefab, hex.GetWorldPosition(), Quaternion.identity, this.transform);

                MeshRenderer meshRenderer = hexObj.GetComponentInChildren<MeshRenderer>();
                meshRenderer.material = hexMats[Random.Range(0, hexMats.Length)];
            }
        }

        //StaticBatchingUtility.Combine(this.gameObject);
    }
}
