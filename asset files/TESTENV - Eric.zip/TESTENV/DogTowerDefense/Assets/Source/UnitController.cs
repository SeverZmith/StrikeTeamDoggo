﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnitController : MonoBehaviour
{
    public void ActivateMovement()
    {

    }

    public void DeactivateMovement()
    {

    }
}
