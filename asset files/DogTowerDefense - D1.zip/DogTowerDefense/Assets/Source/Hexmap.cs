﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hexmap : MonoBehaviour
{
    // Unity Functions
    void Start()
    {
        GenerateTilemap();
        flowField(HexList[Random.Range(0, HexList.Count)]);
    }

    // Member Variables
    public GameObject hexPrefab = null;
    public Material[] hexMats = null;

    [SerializeField] private int hexMapRadius = 9;
    private Hex[ , ] hexes = null;

    List<Hex> HexList = new List<Hex>();

    // Public Methods
    public void GenerateTilemap()
    {
        for (int q = hexMapRadius; q >= -hexMapRadius; q--)
        {
            int qSign;
            if (q != 0)
                qSign = Mathf.Abs(q) / q;
            else
                qSign = 1;

            for (int r = hexMapRadius * qSign - q; r != hexMapRadius * -qSign - qSign; r -= qSign)
            {
                // Instantiate hex tiles (parent transform to this Tilemap)
                Hex hex = new Hex(q, r, 1f);

                GameObject hexObj = (GameObject)Instantiate(hexPrefab, hex.GetWorldPosition(), Quaternion.identity, this.transform);

                hex.SetHexObj(hexObj);

                MeshRenderer meshRenderer = hexObj.GetComponentInChildren<MeshRenderer>();
                meshRenderer.material = hexMats[Random.Range(0, hexMats.Length)];

                HexList.Add(hex);
            }
        }

        // check for and store neighbors in Hex
        foreach (Hex hexagon in HexList)
        {
            foreach (Hex neighbor in HexList)
            {
                if ((neighbor.q == hexagon.q + 1 && (neighbor.r == hexagon.r || neighbor.r == hexagon.r - 1))
                    || (neighbor.q == hexagon.q - 1 && (neighbor.r == hexagon.r || neighbor.r == hexagon.r + 1))
                    || (neighbor.q == hexagon.q && (neighbor.r == hexagon.r - 1 || neighbor.r == hexagon.r + 1)))
                {
                    hexagon.AddNeighbor(neighbor);
                }
            }

        }

        //StaticBatchingUtility.Combine(this.gameObject);
    }

    void flowField(Hex goal)
    {
        int frontier = 0;

        List<Hex> queue = new List<Hex>();
        foreach (Hex hex in HexList)
        {
            queue.Add(hex);
        }
        List<Distance> distance = new List<Distance>();
        Distance curDistance = new Distance(goal, frontier);
        distance.Add(curDistance);
        queue.Remove(goal);

        List<Hex> currentGroup = new List<Hex>();
        List<Hex> nextGroup = new List<Hex>();
        currentGroup.Add(goal);

        while (queue.Count > 0)
        {
            frontier++;
            foreach (Hex currentHex in currentGroup)
            {
                foreach (Hex neighbor in currentHex.Neighbors)
                {
                    if (queue.Contains(neighbor)) // TODO: also check if obtacle 
                    {
                        nextGroup.Add(neighbor);
                        curDistance = new Distance(neighbor, frontier);
                        distance.Add(curDistance);
                        queue.Remove(neighbor);
                    }
                }
            }
            currentGroup.Clear();
            foreach (Hex hex in nextGroup)
            {
                currentGroup.Add(hex);
            }
            nextGroup.Clear();
        }
        foreach (Distance hexDist in distance)
        {
            
            hexDist.hexagon.HexObj.GetComponentInChildren<TextMesh>().text = string.Format("{0}", hexDist.dist);
        }
    }

    public struct Distance
    {
        public Hex hexagon;
        public int dist;

        public Distance (Hex hex, int distance)
        {
            hexagon = hex;
            dist = distance;
        }
    }

}
